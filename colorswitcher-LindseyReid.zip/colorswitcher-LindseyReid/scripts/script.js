document.getElementById("button1").onclick = color1;
    function color1 () {
        document.getElementById("fullBody").style.backgroundColor = "#892B64";

    };

    document.getElementById("button2").onclick = color2;
    function color2 () {
        document.getElementById("fullBody").style.backgroundColor = '#5C4D7D';

    };
    
    document.getElementById("button3").onclick = color3;
    function color3 () {
        document.getElementById("fullBody").style.backgroundColor = '#455E89';

    };

    document.getElementById("reset").onclick = reset;
    function reset () {
        document.getElementById("fullBody").style.backgroundColor = 'white';

    };
    
    //   color pallet =  https://coolors.co/b7094c-a01a58-892b64-723c70-5c4d7d-455e89-2e6f95-1780a1-0091ad 